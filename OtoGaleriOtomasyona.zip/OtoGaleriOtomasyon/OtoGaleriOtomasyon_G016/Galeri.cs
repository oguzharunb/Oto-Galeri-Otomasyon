﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OtoGaleriOtomasyon_G016
{





    public class Galeri
    {


        public List<Araba> Arabalar = new List<Araba>();


        public bool PlakaGalerideMi(string plaka)
        {
            foreach (Araba item in Arabalar)
            {
                if (item.Plaka == plaka && item.Durum == DURUM.Galeride)
                {
                    return true;
                }

                else if (item.Plaka == plaka && item.Durum == DURUM.Kirada)
                {

                    return false;
                }

            }


            return false;
        }





        public bool PlakaVarMi(string plaka)
        {
            foreach (Araba item in Arabalar)
            {
                if (plaka == item.Plaka)
                {
                    return true;
                }
            }

            return false;

        }

        public int ToplamAracSayisi
        {
            get
            {
                return this.Arabalar.Count;
            }
        }
        public int KiradakiAracSayisi
        {
            get
            {
                int adet = 0;
                foreach (Araba item in this.Arabalar)
                {
                    if (item.Durum == DURUM.Kirada)
                    {
                        adet++;
                    }
                }
                return adet;
            }
        }
        public int GaleridekiAracSayisi
        {
            get
            {
                return ToplamAracSayisi - KiradakiAracSayisi;
            }
        }

        public int ToplamAracKiralanmaSuresi
        {
            get
            {
                int toplam = 0;

                foreach (Araba item in Arabalar)
                {
                    foreach (int a in item.KiralanmaSureleri)
                    {
                        toplam += a;

                    }
                }
                return toplam;
            }
        }
        public int ToplamAracKiralanmaAdedi
        {
            get
            {
                int toplam = 0;

                foreach (Araba item in Arabalar)
                {
                    toplam += item.KiralanmaSayisi;
                }

                return toplam;
            }
        }

        public double Ciro
        {
            get
            {

                double toplam = 0;
                foreach (Araba item in Arabalar)
                {
                    double sayi = item.ToplamKiralanmaSuresi * item.KiralamaBedeli;
                    toplam += sayi;

                }

                return toplam;
            }
        }




        public void ArabaKirala(string plaka, int kiralamaSuresi)
        {

            //Araba a = null;

            foreach (Araba item in this.Arabalar)
            {

                if (item.Plaka == plaka)
                {
                    item.KiralanmaSureleri.Add(kiralamaSuresi);
                    item.Durum = DURUM.Kirada;
                    break;
                }

            }

        }



        public void ArabaEkle(string Plaka, string marka, float kiralamaBedeli, ARAC_TIPI aracTipi)
        {








            Araba a = new Araba(Plaka, marka, kiralamaBedeli, aracTipi);

            this.Arabalar.Add(a);








        }


        public void ArabaTeslimAl(string plaka)
        {



            foreach (Araba item in Arabalar)
            {
                if (item.Plaka == plaka)
                {

                    item.Durum = DURUM.Galeride;
                    return;
                }

            }



        }


        public bool ArabaSil(string plaka)
        {
            int index = 0;

            foreach (Araba item in Arabalar)
            {

                if (item.Plaka == plaka && item.Durum == DURUM.Kirada)
                {
                    Console.WriteLine("Araç kirada olduğu için silinme işlemi yapılamaz.");
                    return false;
                }
                
                
                
                if (item.Plaka == plaka)
                {
                    Arabalar.RemoveAt(index);
                    Console.WriteLine();
                    Console.WriteLine("Araç silindi.");
                    return true;
                }

                index++;
            }

            int asdasd;
            if (int.TryParse(plaka.Substring(0, 2), out asdasd) && plaka.Length >= 3)
            {
                Console.WriteLine("Bu plakaya ait araç bulunmamaktadır.");
                return false;
            }


            
            Console.WriteLine("Bu şekilde plaka girişi yapamazsınız. Tekrar deneyin.");
            return false;
        }

    }


}
