﻿using System;

namespace OtoGaleriOtomasyon_G016
{
    class Program
    {

        static Galeri OtoGaleri = new Galeri();

        static void Main(string[] args)
        {

            Uygulama();
        }


        static void Uygulama()
        {




            SahteVeriGir();
            Menu();
            while (true)
            {
            SecimAl();
            }






        }

        static void SecimAl()
        {
            Console.WriteLine();

            Console.Write("Seçiminiz: ");
            string secim = Console.ReadLine().ToUpper();

            Console.WriteLine();

            switch (secim)
            {

                case "1":
                case "K":
                    ArabaKiralamaIslemi(); // doğru
                    break;
                case "2":
                case "T":
                    ArabaTeslimAl(); //doğru
                    break;
                case "3":
                case "R":
                    KiradakileriArabalariListele(); // doğru
                    break;
                case "4":
                case "M":
                    GaleridekiArabalariListele(); // doğru
                    break;
                case "5":
                case "A":
                    TumArabalariListele(); //doğru
                    break;
                case "6":
                case "Y":
                    ArabaEkle(); // doğru
                    break;
                case "7":
                case "S":
                    ArabaSil(); // doğru
                        break;
                case "8":
                case "G":
                    BilgileriGoster(); //doğru
                    break;

                default:
                  
                    break;
            }



        }


        static void ArabaKiralamaIslemi()
        {


            string plaka;
            int kiralamasuresi = 0;
            int asd;

            Console.WriteLine("-Araç Kirala -");


            do
            {

                Console.Write("Kiralanacak aracın plakası: ");
                plaka = Console.ReadLine().ToUpper();

                bool ksuresikontrol = false;

                if (OtoGaleri.PlakaVarMi(plaka) && OtoGaleri.PlakaGalerideMi(plaka))
                {
                    do
                    {

                        Console.Write("Kiralama süresi: ");
                        ksuresikontrol = int.TryParse(Console.ReadLine(), out kiralamasuresi);

                        if (ksuresikontrol == false)
                        {
                            Console.WriteLine("Hatalı giriş yapıldı, tekrar deneyin.");
                            continue;

                        }

                    } while (ksuresikontrol == false);


                    break;


                }


 

                else if (int.TryParse(plaka.Substring(0, 2), out asd) && plaka.Length > 2)
                {

                    Console.WriteLine("Galeriye ait bu plakada bir araç yok.");
                    continue;

                }


                else if (OtoGaleri.PlakaVarMi(plaka) == false)
                {
                    Console.WriteLine("Giriş tanımlanamadı. Tekrar deneyin.");
                    continue;
                }

                else if (OtoGaleri.PlakaGalerideMi(plaka) == false)
                {
                    Console.WriteLine("Araç müsait değil. Başka bir araç seçin.");
                    continue;
                }





            } while (true);

            Console.WriteLine();
            
            Console.WriteLine(plaka + " Plakalı araç " + kiralamasuresi + " saatliğine kiralandı.");

            OtoGaleri.ArabaKirala(plaka, kiralamasuresi);


        }


        static void ArabaTeslimAl()
        {


            string plaka;

            Console.WriteLine("-Araç Teslim -");


            do
            {

                Console.Write("Teslim Edilecek aracın plakası: ");
                plaka = Console.ReadLine().ToUpper();
                int asd;



                if (OtoGaleri.PlakaVarMi(plaka) && !OtoGaleri.PlakaGalerideMi(plaka))
                {


                    break;


                }

                else if (int.TryParse(plaka.Substring(0, 2), out asd) && plaka.Length > 2 )
                {

                    Console.WriteLine("Galeriye ait bu plakada bir araç yok.");
                    continue;

                }
                
                
                else if (OtoGaleri.PlakaVarMi(plaka) == false)
                {
                    Console.WriteLine("Giriş tanımlanamadı. Tekrar deneyin.");
                    continue;
                }

                else if (OtoGaleri.PlakaGalerideMi(plaka) == true)
                {
                    Console.WriteLine("Hatalı giriş yapıldı. Araç zaten galeride.");
                    continue;
                }





            } while (true);

            Console.WriteLine();
            Console.WriteLine("Araç galeride beklemeye alındı.");

            OtoGaleri.ArabaTeslimAl(plaka);








        }


        static void ArabaEkle()
        {

            Console.WriteLine("- Yeni Araç Ekle -");

            bool plakaKontrol;
            string plaka;


            do
            {
                plakaKontrol = false;
                Console.Write("Plaka: ");
                plaka = Console.ReadLine().ToUpper();
                plakaKontrol = OtoGaleri.PlakaVarMi(plaka);

                int deneme;

                if (plaka.Length == 2 || plaka.Length == 1 || !int.TryParse(plaka.Substring(0, 2), out deneme))
                {
                    if (plaka.Length <= 3)
                    {
                        Console.WriteLine("Bu şekilde plaka girişi yapamazsınız. Tekrar deneyin.");
                        plakaKontrol = true;
                        continue;
                    }


                }

                if (plakaKontrol == true)
                {
                    Console.WriteLine("Aynı plakada araç mevcut. Girdiğiniz plakayı kontrol edin.");

                }

            } while (plakaKontrol == true);





            Console.Write("Marka: ");
            string marka = Console.ReadLine();






            bool kbedelkontrol;
            float kBedeli;
            do
            {
                Console.Write("Kiralama Bedeli: ");
                kbedelkontrol = false;

                kbedelkontrol = float.TryParse(Console.ReadLine(), out kBedeli);

                if (!kbedelkontrol)
                {
                    Console.WriteLine("Hatalı giriş yapıldı. Tekrar deneyin.");
                }

            } while (!kbedelkontrol);

            Console.WriteLine("Araç Tipleri");

            int aracTipSecim;
            ARAC_TIPI aracTip = ARAC_TIPI.Empty;
            bool tipKontrol;


            Console.WriteLine("- SUV için 1");
            Console.WriteLine("- Hatchback için 2");
            Console.WriteLine("- Sedan için 3");



            do
            {
                tipKontrol = false;


                Console.Write("Araç Tipi: ");



                int.TryParse(Console.ReadLine(), out aracTipSecim);




                switch (aracTipSecim)
                {

                    case 1:
                        aracTip = ARAC_TIPI.SUV;
                        break;
                    case 2:
                        aracTip = ARAC_TIPI.Hatchback;
                        break;
                    case 3:
                        aracTip = ARAC_TIPI.Sedan;
                        break;


                    default:
                        tipKontrol = true;
                        Console.WriteLine("Hatalı giriş yapıldı. Tekrar deneyin.");
                        break;
                }



            } while (tipKontrol);

            Console.WriteLine();
            Console.WriteLine("Araç başarılı bir şekilde eklendi.");

            OtoGaleri.ArabaEkle(plaka, marka, kBedeli, aracTip);


        }
        static void Menu()
        {

            Console.WriteLine("--- Galeri Otomasyon ---");
            Console.WriteLine("1 - Araba Kirala(K)");
            Console.WriteLine("2 - Araba Teslim Al(T)");
            Console.WriteLine("3 - Kiradaki arabaları listele(R)");
            Console.WriteLine("4 - Müsait arabaları listele(M)");
            Console.WriteLine("5 - Tüm arabaları listele(A)");
            Console.WriteLine("6 - Yeni araba Ekle(Y)");
            Console.WriteLine("7 - Araba sil(S)");
            Console.WriteLine("8 - Bilgileri göster(G)");

        }
        static void SahteVeriGir()
        {
            OtoGaleri.ArabaEkle("34US2342", "OPEL", 50, ARAC_TIPI.Hatchback);
            OtoGaleri.ArabaEkle("34ARB3434", "FIAT", 70, ARAC_TIPI.Sedan);
            OtoGaleri.ArabaEkle("35ARB3535", "KIA", 60, ARAC_TIPI.SUV);
        }

        static void ArabaSil()
        {

            Console.WriteLine("- Araba Sil -");
            string plaka;
            bool kontrol;
            do
            {

                Console.Write("Silinmek istenen araç plakasını girin: ");
                plaka = Console.ReadLine().ToUpper();




                kontrol = OtoGaleri.ArabaSil(plaka);





            } while (!kontrol);


        }

        static void KiradakileriArabalariListele()
        {

            if (OtoGaleri.KiradakiAracSayisi == 0)
            {
                Console.WriteLine("Kirada araç bulunmamaktadır.");
                return;
            }
            
            
            Console.WriteLine("Plaka          Marka         K. Bedeli      Araç Tipi       K. Sayısı      Durum");
            Console.WriteLine("--------------------------------------------------------------------------------------");

            foreach (Araba item in OtoGaleri.Arabalar)
            {


                
                if (item.Durum == DURUM.Kirada)
                {
                    Console.WriteLine(item.Plaka.PadRight(15) + item.Marka.PadRight(14) + item.KiralamaBedeli.ToString().PadRight(15) + item.AracTipi.ToString().PadRight(16) + item.KiralanmaSayisi.ToString().PadRight(15) + item.Durum.ToString());

                }
            }


        }

        static void GaleridekiArabalariListele()
        {

            if (OtoGaleri.GaleridekiAracSayisi == 0)
            {
                Console.WriteLine("Müsait araç bulunmamaktadır.");
                return;
            }


            Console.WriteLine("Plaka          Marka         K. Bedeli      Araç Tipi       K. Sayısı      Durum");
            Console.WriteLine("--------------------------------------------------------------------------------------");

            foreach (Araba item in OtoGaleri.Arabalar)
            {



                if (item.Durum == DURUM.Galeride)
                {
                    Console.WriteLine(item.Plaka.PadRight(15) + item.Marka.PadRight(14) + item.KiralamaBedeli.ToString().PadRight(15) + item.AracTipi.ToString().PadRight(16) + item.KiralanmaSayisi.ToString().PadRight(15) + item.Durum.ToString());

                }
            }
        }

        static void TumArabalariListele()
        {
            if (OtoGaleri.GaleridekiAracSayisi == 0)
            {
                Console.WriteLine("Galeride araç bulunmamaktadır.");
                return;
            }

            

            Console.WriteLine("Plaka          Marka         K. Bedeli      Araç Tipi       K. Sayısı      Durum");
            Console.WriteLine("--------------------------------------------------------------------------------------");

            foreach (Araba item in OtoGaleri.Arabalar)
            {
                    Console.WriteLine(item.Plaka.PadRight(15) + item.Marka.PadRight(14) + item.KiralamaBedeli.ToString().PadRight(15) + item.AracTipi.ToString().PadRight(16) + item.KiralanmaSayisi.ToString().PadRight(15) + item.Durum.ToString());
            }
        }


        static void BilgileriGoster()
        {
            Console.WriteLine("- Galeri Bilgileri -");
            
            Console.WriteLine("Toplam Araç Sayısı: "           + OtoGaleri.ToplamAracSayisi);
            Console.WriteLine("Kiradaki Araç Sayısı: "         + OtoGaleri.KiradakiAracSayisi);
            Console.WriteLine("Bekleyen Araç Sayısı:"          + OtoGaleri.GaleridekiAracSayisi);
            Console.WriteLine("Toplam araç kiralama süresi:"   + OtoGaleri.ToplamAracKiralanmaSuresi);
            Console.WriteLine("Toplam araç kiralama adedi:"    + OtoGaleri.ToplamAracKiralanmaAdedi);
            Console.WriteLine("Ciro: "                         + OtoGaleri.Ciro);      
        }

    }
}
